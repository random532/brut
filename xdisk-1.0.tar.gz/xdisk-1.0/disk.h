
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <ctype.h>


//#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <inttypes.h>

#include <sys/types.h>
#include <sys/sysctl.h>

#define DEBUG

#ifdef DEBUG
	#define D
#else
	#define D for(;0;)
#endif

//D prrintf(...);

#define TT printf("test statement\n\n\n");

//dbus-uuidgen --ensure


