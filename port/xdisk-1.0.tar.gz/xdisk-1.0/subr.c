/* subroutines */


	/* Hide all widgets.
  * We can then selectively show the ones
  * that are relevant.  
  * */
  
void hide_all() {

gtk_widget_hide(GTK_WIDGET (combo_disks) );
gtk_widget_hide(GTK_WIDGET (combo_types) );
gtk_widget_hide(GTK_WIDGET (combo_fs) );
gtk_widget_hide(GTK_WIDGET (combo4) );
gtk_widget_hide(GTK_WIDGET (combo5) );
gtk_widget_hide(GTK_WIDGET (combo6) );
gtk_widget_hide(GTK_WIDGET (entry4) );
gtk_widget_hide(GTK_WIDGET (entry5) );
gtk_widget_hide(GTK_WIDGET (entry6) );
gtk_widget_hide(GTK_WIDGET (entry7) );
gtk_widget_hide(GTK_WIDGET (entry8) );
gtk_widget_hide(GTK_WIDGET (entry9) );
}



	 /* execute gpart show
	  * put identifyers in front of each entry
	  * return a pointer to modified content 
	  * */
char * parse_gpart() {
	
	
	// copy gpart output to temp file
	
	 system("/sbin/gpart show > /tmp/gpart");
	FILE * fp = fopen("/tmp/gpart", "r");
	if (fp == NULL)
		printf("couldnt open file /tmp/gpart\n");

	//fs = filesize
	
	fseek(fp, 0, SEEK_END);
	int fs = ftell(fp);
	rewind(fp);
	
	//create buffer, copy file to buffer
	
	char * 	ptr1 = malloc(fs+1);
	fread(ptr1, 1, fs, fp);	
	fclose(fp);
	// delete the file pls or use popen
	
	
	// parse buffer, output in 2nd buffer
	
	char * ptr2= malloc(fs+100);
	
	int pa=0; // counter of first buffer
	int pb=0; // counter of second buffer
	
	int cnt=0; // some counter
	int buflen = fs-1; // why -1

	int i=1;	// line counter, for debugging only
	int ai=0;	// disk entry counter, for debugging only

	/* 
	/ first task:
	/ - remove double spaces
	/ - label the two numbers at 
	/ the beginning of each line, see gpart show
	/ - remove diskid entries 
	*/
	 
	
	while( pa < buflen) {
		
	// get the first 2 numbers 
	
	while(cnt != 2) {
		if (( (ptr1[pa] >= 0x30 ) &&  (ptr1[pa] <= 0x39 )  )) {
			
			// we found a number, so increase cnt
			cnt++;
			// set an identifier
			if (cnt== 1)
				ptr2[pb] =  '!';
			if (cnt == 2)
				ptr2[pb] =  ':';
			pb++;
			
			//write number in 2nd buffer
			
			while (ptr1[pa] !=  ' ') {
				ptr2[pb] = ptr1[pa];
				pa++;
				pb++; 
				
			}

		}
		// else continue the search
		else
			pa++;
	}
		
	cnt=0;

	// skip space characters
	while(ptr1[pa] == ' ')
		pa++;

	// diskid
	if( (ptr1[pa] == 'd' ) && (ptr1[pa+1] == 'i') && (ptr1[pa+2] == 's') && (ptr1[pa+3] == 'k') && (ptr1[pa+4] == 'i') && (ptr1[pa+5] == 'd')) {
		D printf("diskid found!\n");
		while(1) {
			if ((ptr1[pa] == 0x0A)  &&  (ptr1[pa+1] == 0x0A)  ) {
				// end of diskid enry, so leave
				break;
				}
			pa++;
			}
		// hack: remove size numbers
		while(ptr2[pb] != '!')
				pb--;
		pb--; // remove newline
		}

	if( (ptr1[pa] == 'g' ) && (ptr1[pa+1] == 'p') && (ptr1[pa+2] == 't') && (ptr1[pa+3] == 'i') && (ptr1[pa+4] == 'd')) {
		while(1) {
			if ((ptr1[pa] == 0x0A)  &&  (ptr1[pa+1] == 0x0A)  ) {
				// end of diskid enry, so leave
				break;
				}
			pa++;
			}
		// hack: remove size numbers
		while(ptr2[pb] != '!')
				pb--;
		pb--; // remove newline
		}

		// disk			
		if (( (ptr1[pa] >=  'a') &&  (ptr1[pa] <= 'z' )  )) {

			// set identifier
			ptr2[pb] =  '$';
			pb++;
			// and copy
			while (ptr1[pa] !=  ' ') {
					ptr2[pb] = ptr1[pa];
					pa++;
					pb++; 
				}
			}
			
// now parse remaining entries

while (ptr1[pa] != 0x0A) {

	// find the next entry
	while(ptr1[pa] == ' ')
		pa++;
						
		// partition number
		if (( (ptr1[pa] >= 0x30 ) &&  (ptr1[pa] <= 0x39 )  )) {

			// set identifier
			ptr2[pb] =  '#';
			pb++;
				
			//and copy
			while (ptr1[pa] !=  ' ') {
				ptr2[pb] = ptr1[pa];
				pa++;
				pb++; 
				}
			}

		// -free-
		else if (ptr1[pa] ==  '-') {
			
			ptr2[pb] =  '=';
			ptr2[pb+1] =  'f';
			ptr2[pb+2] =  'r';
			ptr2[pb+3] =  'e';
			ptr2[pb+4] =  'e';
			pb= pb+5;
			pa = pa+7;
			}

		// type		
		if (( (ptr1[pa] >=  'a') &&  (ptr1[pa] <= 'z' )  )) {

			// set identifier
			ptr2[pb] =  ';';
			pb++;
			// and copy
			while (ptr1[pa] !=  ' ') {
					ptr2[pb] = ptr1[pa];
					pa++;
					pb++; 
				}
			}

		// schemes
		else if (( (ptr1[pa] >=  'A') &&  (ptr1[pa] <= 'Z' )  )) {
			
			// set identifier
			ptr2[pb] =  '%';
			pb++;

			// and copy
			while (ptr1[pa] !=  ' ') {
					ptr2[pb] = ptr1[pa];
					pa++;
					pb++; 
				}
			}
			
		// active		
		else if( ptr1[pa] ==  '[')  {

			// and copy
			while (ptr1[pa] !=  ' ') {
					ptr2[pb] = ptr1[pa];
					pa++;
					pb++; 
				}
			}

		//partition size
		else if ( ptr1[pa] ==  '('  ) {

			// copy
			while (ptr1[pa] !=  ')') {
					ptr2[pb] = ptr1[pa];
					pa++;
					pb++; 
				}
		//	pa++;
			}
			
			pa++;
}		
		
		
	
	// either way, we reached the end of a line
	// use '\n' instead of 0x0A


	ptr2[pb] = '\n';
	pa++;
	pb++;

	// debugging output
	i++;
	D printf("line number: %i\n", i);


	if (ptr1[pa] == 0x0A) { 	//new entry or eof

		ai++;
		D printf("entry: %i, pa=%i, buflen=%i\n", ai, pa, buflen);
		}
	
	}

	// now zero terminate, and print the parsed string
	ptr2[pb-1] ='\0';
	D printf("end reached. size: %i\n-Start-\n%s\n-End-\n", fs, ptr2);
	
	free(ptr1);
	return(ptr2);
	}


	/* popup a message box */
void msg(char * blah) {
	GtkWidget * message = gtk_message_dialog_new(GTK_WINDOW (window), GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, blah);
	gtk_widget_show(message);
	g_signal_connect(message, "response", G_CALLBACK(on_response), NULL);
	
	}
	
	 /* execute camcontrol devlist
	  * write content to treeview 
	  * */
int camcontrol() {
	
	D printf("camcontrol start\n");
							
	 /* first destroy any previous widgets, cleanup  */
	gtk_tree_store_clear(treestore1);
	
	
	char buf[250];
	int i=0;
	int error=0;
	
	FILE * fp = popen("camcontrol devlist", "r");
	if (fp == NULL) {
		printf("camcontrol failed\n");
		msg("couldnt popen");
		return error;
		}
		
	while( fgets(buf, sizeof buf, fp)) {
		
		 /* this might be a permission denied string.*/
		 if( strcmp(buf, "sh: camcontrol: permission denied") == 0 )
		 {
			 msg(buf);
			 pclose(fp);
			 return 1;
			}
		 
		i=0;	
		while(buf[i] !='<')
			i++;
		
		buf[i]=' ';
				
		while(buf[i] !='>')
			i++;

		buf[i]='\0';
		//and write it to textview colum 2
		gtk_tree_store_append(treestore1 ,&iter, NULL);
		gtk_tree_store_set(treestore1, &iter, 0, buf, -1);
		
		while(buf[i] != ',' )
			i++;

		buf[i]='\0';
		
		while(buf[i] != '(') {
 
			i--;
			if(i==0)  {
				printf("error\n");	
				break;
				}
		}
		i++;
		// and write it to textview colum 1
		gtk_tree_store_set(treestore1, &iter, 1, &buf[i], -1);
	
		

	}
	error = pclose(fp);
	D	printf("camcontrol done\n");	
	return 1;
	}
	
	
	 /* execute glabel show
	  * write content to treeview
	  * */
int glabel() {
	
	// first destroy any previous widgets, cleanup

	gtk_tree_store_clear(treestore2);
	
	D printf("glabel start\n");
	char buf[250];
	int i=0;
	int gtype = 0; // offset to label type
	int glabel = 0; // offset to label
	 
	int error=0;
	
	FILE * fp = popen("glabel status", "r");
	if (fp == NULL) {
		printf("popen (glabel...) failed\n");
		return error;
		}

fgets(buf, sizeof buf, fp); // ignore first line

	while( fgets(buf, sizeof buf, fp)) {
		
		i=0;
		// skip spaces at the beginning of each line
		if(buf[i] == ' ') {
			while(buf[i] == ' ')
				i++;
}
	gtype = i;

	// find "/" and zero terminate it
		while(buf[i] != '/')
			i++;
	buf[i]='\0';
	
	glabel = i;
		while(buf[i] != ' ')
			i++;

		buf[i]='\0';
		
		//and write both to textview 
		gtk_tree_store_append(treestore2 ,&iter2, NULL);
		gtk_tree_store_set(treestore2, &iter2, 0, &buf[gtype], -1);
		gtk_tree_store_set(treestore2, &iter2, 1, &buf[glabel], -1);
		
		i++;
		
		// skip "status" entry in the glabel command
		while(buf[i] == ' ')
			i++;
		while(buf[i] != ' ')
			i++;
		while(buf[i] == ' ')
			i++;
		
		// write adaXpX to textview column 3
		gtk_tree_store_set(treestore2, &iter2, 2, &buf[i], -1);
	
		}

		
	error = pclose(fp);

	D printf("glabel done\n");
	return 1;

	}
	

	
	
	 /* execute a command
	  * return with message box
	  * */
	  
int exe(char * cmd) {

	char buf[200];
	
	strcpy(buf, cmd);
	strcat(buf ," 2>&1"); // also capture stderr
	
	FILE * fp = popen(buf, "r");
	if (fp == NULL)
		msg("couldnt popen");
	
	while( fgets(buf, sizeof buf, fp)) {
		//msg(buf);
		}
	msg(buf);
		int suc = pclose(fp)/256;
		printf("%i == exit status of piped process\n\n", suc);
		
	return suc;
}

	/* add missing disks */
void add_missing() {

	// gpart only shows disks with a scheme
	// we need to add the others too
		
		char *sysdisk;
		size_t syslen;
		int error = sysctlbyname("kern.disks", NULL, &syslen, NULL, 0);
			if (error != 0) 
				D printf("sysctl failed");
				
		sysdisk = malloc(syslen);
		error = sysctlbyname("kern.disks", sysdisk, &syslen, NULL, 0);
			if (error != 0) 
				D printf("sysctl failed");
		
	
	char *token;
	const gchar *p;
	const char s[2]=" ";
	GtkWidget *child;
	int row=0;
	GtkWidget *entry;
	

	token = strtok(sysdisk, s);

	// loop through disks
	while (token != NULL ) {
			
		D printf("token: %s\n", token);
		
		// loop through grid entries
		while(1) {
			child = gtk_grid_get_child_at(GTK_GRID (grid1),1 ,row );
			if (child != NULL) { // we found a disk!
			
				p = gtk_entry_get_text(GTK_ENTRY (child));
				D printf("disk: %s\n", p);
				if( strcmp(p, token) == 0) {
					D printf("%s already in grid\n", token);
					break; // no need to add a grid entry
				}

			}
			if(row == row1) {
				//we found nothing, so add this to the grid
				D printf("add %s to grid\n", token);
				
				row1++;
				gtk_grid_insert_row(GTK_GRID (grid1), row1);
				entry = gtk_entry_new();
				gtk_entry_set_width_chars( GTK_ENTRY (entry), 8);
				gtk_editable_set_editable(  GTK_EDITABLE (entry), FALSE);
				gtk_grid_attach(GTK_GRID (grid1), GTK_WIDGET (entry), 1, row1, 1, 1);
				gtk_entry_set_text(GTK_ENTRY(entry), token);
				gtk_widget_show(entry);
				break;
			}
			row++; // next row
			
			}
			// we have a match, so reset, and go o next token
			row=0;		
		token = strtok(NULL, s);
}
	
	
	 free(sysdisk);
	}
	
	
	 /* display the relevant choices
	  * for the gpart command
	  *  */
void on_gpart_combo_changed(GtkWidget *b)  {
	

	char *string;
	string = gtk_combo_box_text_get_active_text( GTK_COMBO_BOX_TEXT (combo1));
	if(string == NULL)
		return;
		
	hide_all();
		
	if(strcmp(string, "destroy ") == 0) {
		D printf("Destroy\n");
		gtk_widget_show(GTK_WIDGET (combo4));		
		}

	else if(strcmp(string, "create") == 0) {
		gtk_widget_show(GTK_WIDGET (combo6) );
		gtk_widget_show(GTK_WIDGET(combo_disks));
		gtk_widget_show(GTK_WIDGET(entry5));
		//gtk_widget_show(GTK_WIDGET(entry7));
		}
	
	else if(strcmp(string, "add") == 0) {
		gtk_widget_show(GTK_WIDGET (combo4));
		gtk_widget_show(GTK_WIDGET (combo_types));
		gtk_widget_show(GTK_WIDGET (entry4));
		gtk_widget_show(GTK_WIDGET (entry6));
		gtk_widget_show(GTK_WIDGET(entry7));
		}
		
	else if(strcmp(string, "modify") == 0) {
		gtk_widget_show(GTK_WIDGET (combo5));
		gtk_widget_show(GTK_WIDGET (combo_types));
		gtk_widget_show(GTK_WIDGET(entry7));
		}
	
	
	else if(strcmp(string, "delete") == 0) {
		gtk_widget_show( GTK_WIDGET (combo5));
		}	
		
	else if(strcmp(string, "set") == 0) {
		gtk_widget_show(GTK_WIDGET (combo6));
		gtk_widget_show(GTK_WIDGET(entry8));
		}	
		
	else if(strcmp(string, "unset") == 0) {
		gtk_widget_show(GTK_WIDGET(combo6));
		gtk_widget_show(GTK_WIDGET(entry8));
		}		 
		
	else if(strcmp(string, "resize") == 0) {
		gtk_widget_show(GTK_WIDGET(combo5));
		gtk_widget_show(GTK_WIDGET (entry4));
		gtk_widget_show(GTK_WIDGET (entry6));
		}	
	
	else if(strcmp(string, "bootcode") == 0) {
		gtk_widget_show(GTK_WIDGET(combo6));
		gtk_widget_show(GTK_WIDGET (entry9));
		}
		
		
	else if(strcmp(string, "file system") == 0) {
		gtk_widget_show(GTK_WIDGET(combo6));
		gtk_widget_show(GTK_WIDGET(combo_fs));
	}
	
	g_free(string);
}

